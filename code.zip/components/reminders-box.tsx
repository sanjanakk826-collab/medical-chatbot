"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Trash2, Plus, Clock, Bell, Volume2 } from "lucide-react"
import { useLanguage } from "@/context/language-context"

interface Reminder {
  id: string
  type: "tablet" | "diet" | "exercise"
  time: string
  period: "AM" | "PM"
  message: string
  status: "pending" | "taken" | "missed"
}

export default function RemindersBox() {
  const { t } = useLanguage()
  const [reminders, setReminders] = useState<Reminder[]>([])
  const [showForm, setShowForm] = useState(false)
  const [newReminder, setNewReminder] = useState({
    type: "tablet" as const,
    time: "",
    period: "AM" as const,
    message: "",
  })
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [alarmEnabled, setAlarmEnabled] = useState(false)
  const [alarmActive, setAlarmActive] = useState(false)
  const audioContextRef = useRef<AudioContext | null>(null)
  const oscillatorRef = useRef<OscillatorNode | null>(null)
  const gainRef = useRef<GainNode | null>(null)

  useEffect(() => {
    const saved = localStorage.getItem("reminders")
    if (saved) {
      setReminders(JSON.parse(saved))
    }
    const savedNotif = localStorage.getItem("notificationsEnabled")
    setNotificationsEnabled(savedNotif === "true")
    const savedAlarm = localStorage.getItem("alarmEnabled")
    setAlarmEnabled(savedAlarm === "true")
  }, [])

  useEffect(() => {
    localStorage.setItem("reminders", JSON.stringify(reminders))
  }, [reminders])

  useEffect(() => {
    if (!notificationsEnabled && !alarmEnabled) return

    const interval = setInterval(() => {
      const now = new Date()
      const hours = String(now.getHours()).padStart(2, "0")
      const minutes = String(now.getMinutes()).padStart(2, "0")

      reminders.forEach((reminder) => {
        if (reminder.status === "pending") {
          const [reminderHour, reminderMin] = reminder.time.split(":")
          const reminderHour24 = convertTo24Hour(reminder.time, reminder.period)

          if (reminderHour24 === hours && reminderMin === minutes) {
            if (notificationsEnabled) {
              sendNotification(reminder)
            }
            if (alarmEnabled) {
              playAlarm()
            }
          }
        }
      })
    }, 10000) // Check every 10 seconds for real-time accuracy

    return () => clearInterval(interval)
  }, [reminders, notificationsEnabled, alarmEnabled])

  const convertTo24Hour = (time: string, period: string): string => {
    const [hour, minute] = time.split(":")
    let hour24 = Number.parseInt(hour)

    if (period === "PM" && hour24 !== 12) {
      hour24 += 12
    } else if (period === "AM" && hour24 === 12) {
      hour24 = 0
    }

    return String(hour24).padStart(2, "0")
  }

  const convertTo12Hour = (hour24: number): { hour: string; period: "AM" | "PM" } => {
    let hour = hour24
    let period: "AM" | "PM" = "AM"

    if (hour >= 12) {
      period = "PM"
      if (hour > 12) hour -= 12
    } else if (hour === 0) {
      hour = 12
    }

    return { hour: String(hour).padStart(2, "0"), period }
  }

  const sendNotification = (reminder: Reminder) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(t("reminders.notification"), {
        body: `${reminder.message} at ${reminder.time} ${reminder.period}`,
        icon: "/placeholder-logo.svg",
        tag: `reminder-${reminder.id}`,
        requireInteraction: true,
      })
    }
  }

  const playAlarm = () => {
    if (alarmActive) return

    setAlarmActive(true)

    const audioContext = audioContextRef.current || new (window.AudioContext || (window as any).webkitAudioContext)()
    audioContextRef.current = audioContext

    // Stop any existing alarm
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop()
      } catch {
        // Already stopped
      }
    }

    // Create continuous alarm with pattern
    const osc = audioContext.createOscillator()
    const gain = audioContext.createGain()

    oscillatorRef.current = osc
    gainRef.current = gain

    osc.connect(gain)
    gain.connect(audioContext.destination)

    osc.frequency.value = 800
    gain.gain.setValueAtTime(0.3, audioContext.currentTime)

    osc.start()

    // Create pulsing effect - beep on and off
    const now = audioContext.currentTime
    for (let i = 0; i < 10; i++) {
      gain.gain.setValueAtTime(0.3, now + i * 0.4)
      gain.gain.setValueAtTime(0, now + i * 0.4 + 0.2)
    }

    // Stop after 4 seconds
    osc.stop(now + 4)

    // Auto-stop alarm after 4 seconds
    setTimeout(() => {
      setAlarmActive(false)
    }, 4000)
  }

  // Stop alarm manually
  const stopAlarm = () => {
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop()
      } catch {
        // Already stopped
      }
    }
    setAlarmActive(false)
  }

  const toggleNotifications = async () => {
    if (!("Notification" in window)) {
      alert("Browser does not support notifications")
      return
    }

    if (Notification.permission === "granted") {
      const newState = !notificationsEnabled
      setNotificationsEnabled(newState)
      localStorage.setItem("notificationsEnabled", String(newState))
    } else if (Notification.permission !== "denied") {
      const permission = await Notification.requestPermission()
      if (permission === "granted") {
        setNotificationsEnabled(true)
        localStorage.setItem("notificationsEnabled", "true")
      }
    }
  }

  const toggleAlarm = () => {
    const newState = !alarmEnabled
    setAlarmEnabled(newState)
    localStorage.setItem("alarmEnabled", String(newState))
  }

  const addReminder = () => {
    if (!newReminder.time || !newReminder.message) return

    const reminder: Reminder = {
      id: Date.now().toString(),
      type: newReminder.type,
      time: newReminder.time,
      period: newReminder.period,
      message: newReminder.message,
      status: "pending",
    }

    setReminders([...reminders, reminder])
    setNewReminder({ type: "tablet", time: "", period: "AM", message: "" })
    setShowForm(false)
  }

  const updateStatus = (id: string, status: Reminder["status"]) => {
    setReminders(reminders.map((r) => (r.id === id ? { ...r, status } : r)))
  }

  const deleteReminder = (id: string) => {
    setReminders(reminders.filter((r) => r.id !== id))
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "tablet":
        return "bg-red-950"
      case "diet":
        return "bg-green-950"
      case "exercise":
        return "bg-blue-950"
      default:
        return "bg-slate-700"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "taken":
        return "text-green-400"
      case "pending":
        return "text-yellow-400"
      case "missed":
        return "text-red-400"
      default:
        return "text-slate-400"
    }
  }

  return (
    <Card className="border-slate-700 bg-slate-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg text-blue-400">{t("reminders.title")}</CardTitle>
            <CardDescription className="text-slate-400 text-xs">{t("reminders.subtitle")}</CardDescription>
          </div>
          <Button size="sm" onClick={() => setShowForm(!showForm)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-1" />
            {t("reminders.add")}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={toggleNotifications}
            className={`flex-1 ${notificationsEnabled ? "bg-blue-600 hover:bg-blue-700" : "bg-slate-700 hover:bg-slate-600"}`}
          >
            <Bell className="h-4 w-4 mr-1" />
            {notificationsEnabled ? t("reminders.disableNotifications") : t("reminders.enableNotifications")}
          </Button>
          <Button
            size="sm"
            onClick={toggleAlarm}
            className={`flex-1 ${alarmEnabled ? "bg-blue-600 hover:bg-blue-700" : "bg-slate-700 hover:bg-slate-600"}`}
          >
            <Volume2 className="h-4 w-4 mr-1" />
            {alarmEnabled ? "🔊" : "🔇"} {t("reminders.enableNotifications").includes("Enable") ? "Alert" : "Alert"}
          </Button>
        </div>

        {alarmActive && (
          <div className="p-3 bg-red-950 border border-red-700 rounded-lg flex items-center justify-between">
            <span className="text-red-400 font-medium animate-pulse">⏰ Alarm Active!</span>
            <Button size="sm" onClick={stopAlarm} className="bg-red-700 hover:bg-red-800">
              Stop
            </Button>
          </div>
        )}

        {showForm && (
          <div className="p-4 bg-slate-700 rounded-lg space-y-3">
            <select
              value={newReminder.type}
              onChange={(e) => setNewReminder({ ...newReminder, type: e.target.value as any })}
              className="w-full rounded border border-slate-600 bg-slate-600 px-2 py-1 text-slate-50 text-sm"
            >
              <option value="tablet">{t("reminders.tablet")}</option>
              <option value="diet">{t("reminders.diet")}</option>
              <option value="exercise">{t("reminders.exercise")}</option>
            </select>

            <div className="flex gap-2">
              <input
                type="time"
                value={newReminder.time}
                onChange={(e) => setNewReminder({ ...newReminder, time: e.target.value })}
                className="flex-1 rounded border border-slate-600 bg-slate-600 px-2 py-1 text-slate-50 text-sm"
              />
              <select
                value={newReminder.period}
                onChange={(e) => setNewReminder({ ...newReminder, period: e.target.value as "AM" | "PM" })}
                className="w-20 rounded border border-slate-600 bg-slate-600 px-2 py-1 text-slate-50 text-sm font-medium"
              >
                <option value="AM">AM</option>
                <option value="PM">PM</option>
              </select>
            </div>

            <Input
              placeholder={t("reminders.message")}
              value={newReminder.message}
              onChange={(e) => setNewReminder({ ...newReminder, message: e.target.value })}
              className="border-slate-600 bg-slate-600 text-slate-50 text-sm"
            />
            <Button onClick={addReminder} size="sm" className="w-full bg-green-600 hover:bg-green-700">
              {t("reminders.save")}
            </Button>
          </div>
        )}

        <div className="space-y-2 max-h-64 overflow-y-auto">
          {reminders.length === 0 ? (
            <p className="text-slate-500 text-sm">{t("reminders.empty")}</p>
          ) : (
            reminders.map((reminder) => (
              <div key={reminder.id} className={`p-3 rounded-lg ${getTypeColor(reminder.type)}`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-slate-300" />
                      <span className="font-medium text-slate-200">
                        {reminder.time} {reminder.period}
                      </span>
                      <span className={`text-xs font-medium ${getStatusBadge(reminder.status)}`}>
                        {t(`reminders.${reminder.status}`)}
                      </span>
                    </div>
                    <p className="text-slate-300 text-sm mt-1">{reminder.message}</p>
                  </div>
                  <div className="flex gap-1">
                    {reminder.status !== "taken" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => updateStatus(reminder.id, "taken")}
                        className="h-7 px-2 text-xs text-green-400 hover:bg-slate-700"
                      >
                        {t("reminders.marked")}
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteReminder(reminder.id)}
                      className="h-7 px-2 text-red-400 hover:bg-slate-700"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
