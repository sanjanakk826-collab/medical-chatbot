"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"

interface SignupPageProps {
  onLoginClick: () => void
  onSignupSuccess: () => void
}

export default function SignupPage({ onLoginClick, onSignupSuccess }: SignupPageProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [error, setError] = useState("")

  const handleSignup = () => {
    if (!username || !password || !confirmPassword) {
      setError("Please fill in all fields")
      return
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match")
      return
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters")
      return
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    if (users.some((u: any) => u.username === username)) {
      setError("Username already exists")
      return
    }

    const newUser = { id: Date.now(), username, password }
    users.push(newUser)
    localStorage.setItem("users", JSON.stringify(users))
    localStorage.setItem("user", JSON.stringify(newUser))
    onSignupSuccess()
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md border-slate-700 bg-slate-800">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl text-blue-400">Create Account</CardTitle>
          <CardDescription className="text-slate-400">Sign up to get started</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex gap-2 rounded-lg bg-red-950 p-3 text-red-200">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-200">Username</label>
            <Input
              type="text"
              placeholder="Choose a username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="border-slate-600 bg-slate-700 text-slate-50 placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-200">Password</label>
            <Input
              type="password"
              placeholder="Create a password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-slate-600 bg-slate-700 text-slate-50 placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-200">Confirm Password</label>
            <Input
              type="password"
              placeholder="Confirm your password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="border-slate-600 bg-slate-700 text-slate-50 placeholder:text-slate-500"
            />
          </div>

          <Button onClick={handleSignup} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Create Account
          </Button>

          <div className="text-center text-sm text-slate-400">
            Already have an account?{" "}
            <button onClick={onLoginClick} className="text-blue-400 hover:text-blue-300 font-medium">
              Sign in
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
