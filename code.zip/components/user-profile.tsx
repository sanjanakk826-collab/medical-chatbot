"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"

interface RegistrationData {
  name: string
  age: number
  bloodGroup: string
  sex: string
  weight: number
  height: number
  systolic: number
  diastolic: number
}

export default function UserProfile() {
  const [profile, setProfile] = useState<RegistrationData | null>(null)
  const [bmi, setBmi] = useState<number | null>(null)

  useEffect(() => {
    const saved = localStorage.getItem("registrationData")
    if (saved) {
      const data = JSON.parse(saved)
      setProfile(data)

      // Calculate BMI
      const calculatedBmi = data.weight / (data.height * data.height)
      setBmi(Math.round(calculatedBmi * 10) / 10)
    }
  }, [])

  if (!profile) {
    return (
      <Card className="border-slate-700 bg-slate-800">
        <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
          <AlertCircle className="h-12 w-12 text-yellow-500" />
          <p className="text-slate-400 text-center">No profile information saved yet. Please complete registration.</p>
        </CardContent>
      </Card>
    )
  }

  const getBMICategory = (bmiValue: number) => {
    if (bmiValue < 18.5) return { category: "Underweight", color: "text-blue-400" }
    if (bmiValue < 25) return { category: "Normal", color: "text-green-400" }
    if (bmiValue < 30) return { category: "Overweight", color: "text-yellow-400" }
    return { category: "Obese", color: "text-red-400" }
  }

  const bmiInfo = bmi ? getBMICategory(bmi) : null

  return (
    <div className="space-y-6">
      <Card className="border-slate-700 bg-slate-800">
        <CardHeader>
          <CardTitle className="text-2xl text-blue-400">{profile.name}</CardTitle>
          <CardDescription className="text-slate-400">Registration Profile</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-slate-400 text-sm">Age</p>
                <p className="text-slate-100 text-lg font-semibold">{profile.age} years</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Sex</p>
                <p className="text-slate-100 text-lg font-semibold">{profile.sex}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Blood Group</p>
                <p className="text-slate-100 text-lg font-semibold">{profile.bloodGroup}</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Weight</p>
                <p className="text-slate-100 text-lg font-semibold">{profile.weight} kg</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-slate-400 text-sm">Height</p>
                <p className="text-slate-100 text-lg font-semibold">{profile.height} m</p>
              </div>
              <div>
                <p className="text-slate-400 text-sm">Blood Pressure</p>
                <p className="text-slate-100 text-lg font-semibold">
                  {profile.systolic}/{profile.diastolic} mmHg
                </p>
              </div>
              {bmi && (
                <div>
                  <p className="text-slate-400 text-sm">BMI</p>
                  <p className={`text-lg font-semibold ${bmiInfo?.color}`}>
                    {bmi} ({bmiInfo?.category})
                  </p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
