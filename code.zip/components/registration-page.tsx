"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, CheckCircle } from "lucide-react"

interface RegistrationPageProps {
  onRegistrationComplete: () => void
}

export default function RegistrationPage({ onRegistrationComplete }: RegistrationPageProps) {
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    bloodGroup: "",
    sex: "",
    weight: "",
    height: "",
    systolic: "",
    diastolic: "",
  })
  const [error, setError] = useState("")
  const [showSuccess, setShowSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = () => {
    if (
      !formData.name ||
      !formData.age ||
      !formData.bloodGroup ||
      !formData.sex ||
      !formData.weight ||
      !formData.height ||
      !formData.systolic ||
      !formData.diastolic
    ) {
      setError("Please fill in all fields")
      return
    }

    const user = JSON.parse(localStorage.getItem("user") || "{}")
    const registrationData = {
      ...formData,
      age: Number.parseInt(formData.age),
      weight: Number.parseFloat(formData.weight),
      height: Number.parseFloat(formData.height),
      systolic: Number.parseInt(formData.systolic),
      diastolic: Number.parseInt(formData.diastolic),
    }

    localStorage.setItem("registrationData", JSON.stringify(registrationData))
    setShowSuccess(true)
    setTimeout(onRegistrationComplete, 2000)
  }

  if (showSuccess) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-md border-green-900 bg-green-950">
          <CardContent className="flex flex-col items-center justify-center py-12 space-y-4">
            <CheckCircle className="h-16 w-16 text-green-400" />
            <h2 className="text-xl font-semibold text-green-400">Thank you for registration!</h2>
            <p className="text-center text-green-200 text-sm">Your health profile has been created successfully.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-2xl border-slate-700 bg-slate-800">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl text-blue-400">Complete Your Health Profile</CardTitle>
          <CardDescription className="text-slate-400">Enter your health information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex gap-2 rounded-lg bg-red-950 p-3 text-red-200">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2 space-y-2">
              <label className="text-sm font-medium text-slate-200">Full Name</label>
              <Input
                type="text"
                name="name"
                placeholder="John Doe"
                value={formData.name}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Age</label>
              <Input
                type="number"
                name="age"
                placeholder="30"
                value={formData.age}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Blood Group</label>
              <select
                name="bloodGroup"
                value={formData.bloodGroup}
                onChange={handleChange}
                className="w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-slate-50"
              >
                <option value="">Select</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Sex</label>
              <select
                name="sex"
                value={formData.sex}
                onChange={handleChange}
                className="w-full rounded-md border border-slate-600 bg-slate-700 px-3 py-2 text-slate-50"
              >
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Weight (kg)</label>
              <Input
                type="number"
                name="weight"
                placeholder="70"
                value={formData.weight}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Height (m)</label>
              <Input
                type="number"
                name="height"
                placeholder="1.75"
                value={formData.height}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
                step="0.01"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Blood Pressure Systolic</label>
              <Input
                type="number"
                name="systolic"
                placeholder="120"
                value={formData.systolic}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-200">Blood Pressure Diastolic</label>
              <Input
                type="number"
                name="diastolic"
                placeholder="80"
                value={formData.diastolic}
                onChange={handleChange}
                className="border-slate-600 bg-slate-700 text-slate-50"
              />
            </div>
          </div>

          <Button onClick={handleSubmit} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Complete Registration
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
