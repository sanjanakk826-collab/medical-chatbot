"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Trash2 } from "lucide-react"

interface Message {
  id: string
  type: "user" | "bot"
  text: string
  isEmergency?: boolean
}

export default function ChatHistory() {
  const [history, setHistory] = useState<Message[]>([])

  useEffect(() => {
    const saved = localStorage.getItem("chatHistory")
    if (saved) {
      setHistory(JSON.parse(saved))
    }
  }, [])

  const handleClearHistory = () => {
    if (confirm("Are you sure you want to clear all chat history?")) {
      localStorage.setItem("chatHistory", "[]")
      setHistory([])
    }
  }

  return (
    <Card className="border-slate-700 bg-slate-800">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg text-blue-400">Chat History</CardTitle>
          <CardDescription className="text-slate-400 text-xs">Your previous health consultations</CardDescription>
        </div>
        {history.length > 0 && (
          <Button
            onClick={handleClearHistory}
            variant="outline"
            size="sm"
            className="border-slate-600 text-red-400 hover:bg-red-950 bg-transparent"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <p className="text-slate-400 text-center py-8">No chat history yet. Start a conversation to see it here!</p>
        ) : (
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {history.map((msg) => (
              <div
                key={msg.id}
                className={`p-4 rounded-lg ${
                  msg.type === "user"
                    ? "bg-blue-600 text-white ml-auto w-fit max-w-xs"
                    : msg.isEmergency
                      ? "bg-red-950 text-red-200"
                      : "bg-slate-700 text-slate-100"
                }`}
              >
                {msg.isEmergency && (
                  <div className="flex items-center gap-2 mb-2 font-bold">
                    <AlertTriangle className="h-4 w-4" /> EMERGENCY
                  </div>
                )}
                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
