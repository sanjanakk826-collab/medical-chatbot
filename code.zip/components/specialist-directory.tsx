"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Calendar } from "@/components/ui/calendar"
import { Star, Phone, Mail, Award } from "lucide-react"

const SPECIALISTS = [
  {
    name: "General Physician",
    icon: "👨‍⚕️",
    desc: "General health checkups",
    doctors: [
      {
        name: "Dr. Rajesh Kumar",
        qualification: "MBBS, MD",
        rating: 4.8,
        experience: "12 years",
        phone: "+91-98765-43210",
        email: "rajesh.kumar@health.com",
        fees: "₹500",
        availableSlots: ["09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "02:00 PM", "02:30 PM", "03:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Priya Sharma",
        qualification: "MBBS, MD, PGDM",
        rating: 4.9,
        experience: "10 years",
        phone: "+91-98765-43211",
        email: "priya.sharma@health.com",
        fees: "₹600",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Fri", "Sat", "Sun"],
      },
      {
        name: "Dr. Anil Patel",
        qualification: "MBBS, Diploma in Family Medicine",
        rating: 4.7,
        experience: "8 years",
        phone: "+91-98765-43212",
        email: "anil.patel@health.com",
        fees: "₹450",
        availableSlots: ["08:00 AM", "08:30 AM", "09:00 AM", "05:00 PM", "05:30 PM"],
        workingDays: ["Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Sunita Desai",
        qualification: "MBBS, MD",
        rating: 4.6,
        experience: "9 years",
        phone: "+91-98765-43213",
        email: "sunita.desai@health.com",
        fees: "₹550",
        availableSlots: ["10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM", "04:30 PM"],
        workingDays: ["Mon", "Wed", "Thu", "Fri", "Sun"],
      },
    ],
  },
  {
    name: "Cardiologist",
    icon: "❤️",
    desc: "Heart & cardiovascular",
    doctors: [
      {
        name: "Dr. Amit Singh",
        qualification: "MBBS, MD Cardiology, Fellowship USA",
        rating: 4.9,
        experience: "15 years",
        phone: "+91-98765-43214",
        email: "amit.singh@health.com",
        fees: "₹1000",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      },
      {
        name: "Dr. Neha Patel",
        qualification: "MBBS, MD Cardiology, FACC",
        rating: 4.8,
        experience: "12 years",
        phone: "+91-98765-43215",
        email: "neha.patel@health.com",
        fees: "₹900",
        availableSlots: ["09:30 AM", "10:30 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Mon", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Vikram Chopra",
        qualification: "MBBS, MD, DNB Cardiology",
        rating: 4.7,
        experience: "11 years",
        phone: "+91-98765-43216",
        email: "vikram.chopra@health.com",
        fees: "₹850",
        availableSlots: ["08:00 AM", "09:00 AM", "02:00 PM", "03:00 PM", "04:00 PM"],
        workingDays: ["Tue", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Pulmonologist",
    icon: "🫁",
    desc: "Respiratory & lungs",
    doctors: [
      {
        name: "Dr. Vikram Desai",
        qualification: "MBBS, MD Pulmonology",
        rating: 4.8,
        experience: "10 years",
        phone: "+91-98765-43217",
        email: "vikram.desai@health.com",
        fees: "₹700",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Anjali Roy",
        qualification: "MBBS, MD, Diploma Respiratory Medicine",
        rating: 4.9,
        experience: "13 years",
        phone: "+91-98765-43218",
        email: "anjali.roy@health.com",
        fees: "₹750",
        availableSlots: ["09:30 AM", "10:30 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Wed", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Gastroenterologist",
    icon: "🍽️",
    desc: "Digestive system",
    doctors: [
      {
        name: "Dr. Arjun Gupta",
        qualification: "MBBS, MD Gastroenterology, Fellowship",
        rating: 4.7,
        experience: "11 years",
        phone: "+91-98765-43219",
        email: "arjun.gupta@health.com",
        fees: "₹800",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      },
      {
        name: "Dr. Meera Iyer",
        qualification: "MBBS, MD, DNB Gastroenterology",
        rating: 4.8,
        experience: "9 years",
        phone: "+91-98765-43220",
        email: "meera.iyer@health.com",
        fees: "₹750",
        availableSlots: ["10:00 AM", "11:00 AM", "03:00 PM", "04:00 PM", "05:00 PM"],
        workingDays: ["Mon", "Wed", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Neurologist",
    icon: "🧠",
    desc: "Brain & nervous system",
    doctors: [
      {
        name: "Dr. Sanjay Nair",
        qualification: "MBBS, MD Neurology, Fellowship Europe",
        rating: 4.9,
        experience: "14 years",
        phone: "+91-98765-43221",
        email: "sanjay.nair@health.com",
        fees: "₹900",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
        workingDays: ["Mon", "Wed", "Thu", "Fri"],
      },
      {
        name: "Dr. Divya Malhotra",
        qualification: "MBBS, MD, DNB Neurology",
        rating: 4.7,
        experience: "10 years",
        phone: "+91-98765-43222",
        email: "divya.malhotra@health.com",
        fees: "₹850",
        availableSlots: ["09:30 AM", "10:30 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Tue", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Dermatologist",
    icon: "🩹",
    desc: "Skin & allergies",
    doctors: [
      {
        name: "Dr. Ravi Chopra",
        qualification: "MBBS, MD Dermatology",
        rating: 4.6,
        experience: "8 years",
        phone: "+91-98765-43223",
        email: "ravi.chopra@health.com",
        fees: "₹600",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Aisha Khan",
        qualification: "MBBS, MD, Fellowship Cosmetic Dermatology",
        rating: 4.8,
        experience: "9 years",
        phone: "+91-98765-43224",
        email: "aisha.khan@health.com",
        fees: "₹700",
        availableSlots: ["10:00 AM", "11:00 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Orthopedist",
    icon: "💪",
    desc: "Bones & muscles",
    doctors: [
      {
        name: "Dr. Karthik Reddy",
        qualification: "MBBS, MD Orthopedics, Fellowship Sports Medicine",
        rating: 4.8,
        experience: "11 years",
        phone: "+91-98765-43225",
        email: "karthik.reddy@health.com",
        fees: "₹750",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      },
      {
        name: "Dr. Priya Verma",
        qualification: "MBBS, MD Orthopedics",
        rating: 4.7,
        experience: "9 years",
        phone: "+91-98765-43226",
        email: "priya.verma@health.com",
        fees: "₹700",
        availableSlots: ["09:30 AM", "10:30 AM", "03:00 PM", "04:00 PM", "05:00 PM"],
        workingDays: ["Wed", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Endocrinologist",
    icon: "⚗️",
    desc: "Hormones & metabolism",
    doctors: [
      {
        name: "Dr. Ashok Mehta",
        qualification: "MBBS, MD Endocrinology",
        rating: 4.7,
        experience: "10 years",
        phone: "+91-98765-43227",
        email: "ashok.mehta@health.com",
        fees: "₹700",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Fri", "Sat"],
      },
      {
        name: "Dr. Kavya Nambiar",
        qualification: "MBBS, MD, Fellowship Endocrinology",
        rating: 4.8,
        experience: "12 years",
        phone: "+91-98765-43228",
        email: "kavya.nambiar@health.com",
        fees: "₹800",
        availableSlots: ["10:00 AM", "11:00 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Tue", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Dietitian",
    icon: "🥗",
    desc: "Nutrition & diet",
    doctors: [
      {
        name: "Dr. Shreya Jain",
        qualification: "BTech Nutrition, Certified Nutritionist",
        rating: 4.9,
        experience: "7 years",
        phone: "+91-98765-43229",
        email: "shreya.jain@health.com",
        fees: "₹400",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      },
      {
        name: "Dr. Nitin Sharma",
        qualification: "MSc Nutrition, Clinical Dietitian",
        rating: 4.7,
        experience: "6 years",
        phone: "+91-98765-43230",
        email: "nitin.sharma@health.com",
        fees: "₹350",
        availableSlots: ["09:30 AM", "10:30 AM", "03:00 PM", "04:00 PM", "05:00 PM"],
        workingDays: ["Mon", "Wed", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
  {
    name: "Psychiatrist",
    icon: "🧘",
    desc: "Mental health",
    doctors: [
      {
        name: "Dr. Rohan Singh",
        qualification: "MBBS, MD Psychiatry, Fellowship ASEAN",
        rating: 4.8,
        experience: "13 years",
        phone: "+91-98765-43231",
        email: "rohan.singh@health.com",
        fees: "₹800",
        availableSlots: ["09:00 AM", "10:00 AM", "11:00 AM", "02:00 PM", "03:00 PM"],
        workingDays: ["Mon", "Tue", "Wed", "Thu", "Fri"],
      },
      {
        name: "Dr. Swati Pandey",
        qualification: "MBBS, MD, Counselor Certification",
        rating: 4.9,
        experience: "11 years",
        phone: "+91-98765-43232",
        email: "swati.pandey@health.com",
        fees: "₹850",
        availableSlots: ["10:00 AM", "11:00 AM", "03:00 PM", "04:00 PM"],
        workingDays: ["Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      },
    ],
  },
]

interface Doctor {
  name: string
  qualification: string
  rating: number
  experience: string
  phone: string
  email: string
  fees: string
  availableSlots: string[]
  workingDays: string[]
}

export default function SpecialistDirectory() {
  const [expanded, setExpanded] = useState<string | null>(null)
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)
  const [bookingDate, setBookingDate] = useState<Date | undefined>(undefined)
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)

  const handleBookConsultation = () => {
    if (selectedDoctor && bookingDate && selectedSlot) {
      const booking = {
        doctor: selectedDoctor.name,
        date: bookingDate.toLocaleDateString(),
        time: selectedSlot,
        phone: selectedDoctor.phone,
        email: selectedDoctor.email,
        fees: selectedDoctor.fees,
      }

      const bookings = JSON.parse(localStorage.getItem("bookings") || "[]")
      bookings.push(booking)
      localStorage.setItem("bookings", JSON.stringify(bookings))

      alert(`Consultation booked with ${selectedDoctor.name} on ${bookingDate.toLocaleDateString()} at ${selectedSlot}`)
      setSelectedDoctor(null)
      setBookingDate(undefined)
      setSelectedSlot(null)
    }
  }

  return (
    <Card className="border-slate-700 bg-slate-800 w-full">
      <CardHeader>
        <CardTitle className="text-lg text-blue-400">Specialist Directory</CardTitle>
        <CardDescription className="text-slate-400 text-xs">
          Connect with healthcare professionals and book consultations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[600px] overflow-y-auto">
          {SPECIALISTS.map((specialist, idx) => (
            <div key={idx} className="p-4 bg-slate-700 rounded-lg hover:bg-slate-600 transition">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="text-2xl mb-1">{specialist.icon}</div>
                  <p className="font-medium text-slate-100 text-sm">{specialist.name}</p>
                  <p className="text-slate-400 text-xs mb-2">{specialist.desc}</p>
                </div>
                <button
                  onClick={() => setExpanded(expanded === specialist.name ? null : specialist.name)}
                  className="text-blue-400 hover:text-blue-300 font-bold text-lg"
                >
                  {expanded === specialist.name ? "−" : "+"}
                </button>
              </div>

              {expanded === specialist.name && (
                <div className="mt-3 pt-3 border-t border-slate-600 space-y-2">
                  <p className="text-xs font-semibold text-blue-300 mb-3">Consultants Available:</p>
                  {specialist.doctors.map((doctor, doctorIdx) => (
                    <div
                      key={doctorIdx}
                      className="bg-slate-800 p-3 rounded-lg border border-slate-600 hover:border-blue-500 transition"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <p className="text-sm font-semibold text-slate-100">{doctor.name}</p>
                          <p className="text-xs text-slate-400">{doctor.qualification}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex items-center gap-1">
                              <Star className="h-3 w-3 text-yellow-400" fill="currentColor" />
                              <span className="text-xs text-slate-300">{doctor.rating}</span>
                            </div>
                            <span className="text-xs text-slate-400">•</span>
                            <Award className="h-3 w-3 text-slate-400" />
                            <span className="text-xs text-slate-300">{doctor.experience}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2 mt-2 pb-2">
                        <div className="flex items-center gap-2 text-xs text-slate-300">
                          <Phone className="h-3 w-3 text-blue-400" />
                          <span>{doctor.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-300">
                          <Mail className="h-3 w-3 text-blue-400" />
                          <span>{doctor.email}</span>
                        </div>
                        <div className="text-xs font-semibold text-blue-400">Consultation Fee: {doctor.fees}</div>
                      </div>

                      <Button
                        onClick={() => setSelectedDoctor(doctor)}
                        className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white text-xs py-1 h-8"
                      >
                        Book Consultation
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>

      <Dialog open={!!selectedDoctor} onOpenChange={(open) => !open && setSelectedDoctor(null)}>
        <DialogContent className="bg-slate-800 border-slate-700 text-slate-100 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-blue-400">Book Consultation</DialogTitle>
            <DialogDescription className="text-slate-400">Scheduling with {selectedDoctor?.name}</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold text-slate-100 mb-2">Select Date:</p>
              <Calendar
                mode="single"
                selected={bookingDate}
                onSelect={setBookingDate}
                disabled={(date) => {
                  const day = date.toLocaleDateString("en-US", { weekday: "short" })
                  return !selectedDoctor?.workingDays.includes(day)
                }}
                className="rounded-lg border border-slate-600"
              />
            </div>

            {bookingDate && (
              <div>
                <p className="text-sm font-semibold text-slate-100 mb-2">Available Time Slots:</p>
                <div className="grid grid-cols-3 gap-2">
                  {selectedDoctor?.availableSlots.map((slot) => (
                    <button
                      key={slot}
                      onClick={() => setSelectedSlot(selectedSlot === slot ? null : slot)}
                      className={`p-2 rounded text-xs font-medium transition ${
                        selectedSlot === slot
                          ? "bg-blue-600 text-white"
                          : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="bg-slate-700 p-3 rounded-lg space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Consultation Fee:</span>
                <span className="text-blue-400 font-semibold">{selectedDoctor?.fees}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Selected Date:</span>
                <span className="text-slate-100">{bookingDate?.toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-300">Selected Time:</span>
                <span className="text-slate-100">{selectedSlot || "Not selected"}</span>
              </div>
            </div>

            <Button
              onClick={handleBookConsultation}
              disabled={!bookingDate || !selectedSlot}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 text-white"
            >
              Confirm Booking
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  )
}
