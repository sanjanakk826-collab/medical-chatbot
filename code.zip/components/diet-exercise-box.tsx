"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, Plus, CheckCircle2, Circle } from "lucide-react"

interface RegistrationData {
  weight: number
  height: number
  systolic: number
  diastolic: number
}

interface DietPlan {
  id: string
  disease: string
  breakfast: string
  lunch: string
  dinner: string
  notes: string
  createdDate: string
  completed: boolean
}

interface ExercisePlan {
  id: string
  disease: string
  exerciseName: string
  duration: string
  frequency: string
  intensity: string
  description: string
  createdDate: string
  completed: boolean
}

const calculateBMI = (weight: number, height: number) => {
  return weight / (height * height)
}

const SYMPTOM_DIET_PLANS: Record<string, any> = {
  fever: {
    label: "Fever Care",
    color: "bg-orange-950",
    text: "text-orange-200",
    breakfast: "Light porridge with honey",
    lunch: "Chicken soup with ginger",
    dinner: "Rice water and light vegetables",
    exercise: "Rest - avoid strenuous exercise",
    notes: "Stay hydrated, drink warm liquids",
  },
  "common cold": {
    label: "Cold Recovery",
    color: "bg-cyan-950",
    text: "text-cyan-200",
    breakfast: "Warm milk with turmeric",
    lunch: "Lentil soup with carrots",
    dinner: "Vegetable soup and warm water",
    exercise: "Light walking when feeling better",
    notes: "Vitamin C rich foods, ginger tea",
  },
  "chest pain": {
    label: "Heart Care",
    color: "bg-red-950",
    text: "text-red-200",
    breakfast: "Oatmeal with berries, low salt",
    lunch: "Grilled fish with olive oil",
    dinner: "Steamed vegetables with lean meat",
    exercise: "Consult cardiologist before exercise",
    notes: "Low sodium, high fiber diet. EMERGENCY: Seek medical help immediately",
  },
  cough: {
    label: "Cough Management",
    color: "bg-purple-950",
    text: "text-purple-200",
    breakfast: "Honey with warm milk",
    lunch: "Vegetable khichdi with turmeric",
    dinner: "Soup with garlic and ginger",
    exercise: "Gentle breathing exercises",
    notes: "Avoid cold foods, stay warm",
  },
  "stomach pain": {
    label: "Digestive Care",
    color: "bg-amber-950",
    text: "text-amber-200",
    breakfast: "Plain toast with banana",
    lunch: "Rice with mild dal",
    dinner: "Light salad with olive oil",
    exercise: "Yoga postures for digestion",
    notes: "Small meals, avoid spicy food, drink water slowly",
  },
  flu: {
    label: "Flu Recovery",
    color: "bg-indigo-950",
    text: "text-indigo-200",
    breakfast: "Warm juice with lemon and honey",
    lunch: "Light chicken rice",
    dinner: "Vegetable broth",
    exercise: "Rest for 2-3 days",
    notes: "Stay hydrated, take vitamin supplements",
  },
  diabetes: {
    label: "Diabetes Management",
    color: "bg-green-950",
    text: "text-green-200",
    breakfast: "Oatmeal with almonds",
    lunch: "Brown rice with grilled chicken",
    dinner: "Lentil soup with vegetables",
    exercise: "30 mins walking daily",
    notes: "Low glycemic foods, portion control",
  },
  hypertension: {
    label: "Blood Pressure Control",
    color: "bg-red-950",
    text: "text-red-200",
    breakfast: "Low-salt oatmeal with berries",
    lunch: "Grilled fish with vegetables",
    dinner: "Light salad with olive oil",
    exercise: "Moderate cardio 30-45 mins",
    notes: "Reduce salt intake, increase potassium",
  },
  arthritis: {
    label: "Joint Care",
    color: "bg-yellow-950",
    text: "text-yellow-200",
    breakfast: "Turmeric milk with ginger",
    lunch: "Anti-inflammatory salad",
    dinner: "Light stew with omega-3 fish",
    exercise: "Gentle stretching and swimming",
    notes: "Anti-inflammatory foods, stay hydrated",
  },
}

const getBMICategory = (bmi: number) => {
  if (bmi < 18.5) return "underweight"
  if (bmi < 25) return "normal"
  if (bmi < 30) return "overweight"
  return "obese"
}

const DIET_PLANS = {
  underweight: {
    label: "Underweight",
    color: "bg-blue-950",
    text: "text-blue-200",
    breakfast: "Oats with milk, banana, nuts",
    lunch: "Rice, chicken curry, vegetables",
    dinner: "Chapati, dal, paneer",
    exercise: "Strength training and resistance exercises",
    notes: "Calorie-rich foods, increase protein intake",
  },
  normal: {
    label: "Normal Weight",
    color: "bg-green-950",
    text: "text-green-200",
    breakfast: "Whole grain cereal with fruit",
    lunch: "Salad, grilled chicken, brown rice",
    dinner: "Soup and vegetable stir-fry",
    exercise: "30 minutes cardio, yoga, or walking",
    notes: "Maintain balanced diet and regular exercise",
  },
  overweight: {
    label: "Overweight",
    color: "bg-yellow-950",
    text: "text-yellow-200",
    breakfast: "Oatmeal with green tea",
    lunch: "Salad with grilled fish",
    dinner: "Vegetable soup in small portions",
    exercise: "45 minutes cardio, jogging, or cycling",
    notes: "Control portions, reduce sugar intake",
  },
  obese: {
    label: "Obese",
    color: "bg-red-950",
    text: "text-red-200",
    breakfast: "Green smoothie, boiled egg",
    lunch: "Steamed vegetables with lean protein",
    dinner: "Light soup and salad",
    exercise: "60 minutes walking or swimming",
    notes: "Consult nutritionist, increase water intake",
  },
}

export default function DietExerciseBox() {
  const [plan, setPlan] = useState<any>(null)
  const [bmi, setBMI] = useState<number | null>(null)
  const [warning, setWarning] = useState("")
  const [planSource, setPlanSource] = useState("")

  const [dietPlans, setDietPlans] = useState<DietPlan[]>([])
  const [exercisePlans, setExercisePlans] = useState<ExercisePlan[]>([])
  const [showDietForm, setShowDietForm] = useState(false)
  const [showExerciseForm, setShowExerciseForm] = useState(false)
  const [activeTab, setActiveTab] = useState<"recommended" | "custom-diet" | "custom-exercise">("recommended")

  const [newDietPlan, setNewDietPlan] = useState({
    disease: "",
    breakfast: "",
    lunch: "",
    dinner: "",
    notes: "",
  })

  const [newExercisePlan, setNewExercisePlan] = useState({
    disease: "",
    exerciseName: "",
    duration: "",
    frequency: "",
    intensity: "moderate",
    description: "",
  })

  useEffect(() => {
    const detectedDisease = localStorage.getItem("detectedDisease")

    if (detectedDisease) {
      const symptomPlan = SYMPTOM_DIET_PLANS[detectedDisease.toLowerCase()]
      if (symptomPlan) {
        setPlan(symptomPlan)
        setPlanSource("symptom")
        return
      }
    }

    const data = localStorage.getItem("registrationData")
    if (data) {
      const regData: RegistrationData = JSON.parse(data)
      const calculatedBMI = calculateBMI(regData.weight, regData.height)
      setBMI(calculatedBMI)

      const category = getBMICategory(calculatedBMI)
      setPlan(DIET_PLANS[category as keyof typeof DIET_PLANS])
      setPlanSource("bmi")

      if (regData.systolic > 140 || regData.diastolic > 90) {
        setWarning(
          "⚠️ Low salt diet! Avoid fried food, pickles, and processed food. Include bananas, leafy greens, and low-fat dairy.",
        )
      }
    }

    const savedDietPlans = localStorage.getItem("customDietPlans")
    const savedExercisePlans = localStorage.getItem("customExercisePlans")
    if (savedDietPlans) setDietPlans(JSON.parse(savedDietPlans))
    if (savedExercisePlans) setExercisePlans(JSON.parse(savedExercisePlans))
  }, [])

  useEffect(() => {
    localStorage.setItem("customDietPlans", JSON.stringify(dietPlans))
  }, [dietPlans])

  useEffect(() => {
    localStorage.setItem("customExercisePlans", JSON.stringify(exercisePlans))
  }, [exercisePlans])

  const addDietPlan = () => {
    if (!newDietPlan.disease || !newDietPlan.breakfast || !newDietPlan.lunch || !newDietPlan.dinner) {
      alert("Please fill in all diet plan fields")
      return
    }

    const dietPlan: DietPlan = {
      id: Date.now().toString(),
      ...newDietPlan,
      createdDate: new Date().toLocaleDateString(),
      completed: false,
    }

    setDietPlans([...dietPlans, dietPlan])
    setNewDietPlan({ disease: "", breakfast: "", lunch: "", dinner: "", notes: "" })
    setShowDietForm(false)
  }

  const addExercisePlan = () => {
    if (
      !newExercisePlan.disease ||
      !newExercisePlan.exerciseName ||
      !newExercisePlan.duration ||
      !newExercisePlan.frequency
    ) {
      alert("Please fill in all exercise plan fields")
      return
    }

    const exercisePlan: ExercisePlan = {
      id: Date.now().toString(),
      ...newExercisePlan,
      createdDate: new Date().toLocaleDateString(),
      completed: false,
    }

    setExercisePlans([...exercisePlans, exercisePlan])
    setNewExercisePlan({
      disease: "",
      exerciseName: "",
      duration: "",
      frequency: "",
      intensity: "moderate",
      description: "",
    })
    setShowExerciseForm(false)
  }

  const toggleDietCompletion = (id: string) => {
    setDietPlans(dietPlans.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p)))
  }

  const toggleExerciseCompletion = (id: string) => {
    setExercisePlans(exercisePlans.map((p) => (p.id === id ? { ...p, completed: !p.completed } : p)))
  }

  const deleteDietPlan = (id: string) => {
    setDietPlans(dietPlans.filter((p) => p.id !== id))
  }

  const deleteExercisePlan = (id: string) => {
    setExercisePlans(exercisePlans.filter((p) => p.id !== id))
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2 mb-4">
        <Button
          onClick={() => setActiveTab("recommended")}
          className={`${activeTab === "recommended" ? "bg-blue-600" : "bg-slate-700 hover:bg-slate-600"}`}
        >
          Recommended Plan
        </Button>
        <Button
          onClick={() => setActiveTab("custom-diet")}
          className={`${activeTab === "custom-diet" ? "bg-blue-600" : "bg-slate-700 hover:bg-slate-600"}`}
        >
          My Diet Plans
        </Button>
        <Button
          onClick={() => setActiveTab("custom-exercise")}
          className={`${activeTab === "custom-exercise" ? "bg-blue-600" : "bg-slate-700 hover:bg-slate-600"}`}
        >
          My Exercise Plans
        </Button>
      </div>

      {activeTab === "recommended" && (
        <Card className={`border-slate-700 ${plan?.color || "bg-slate-800"}`}>
          <CardHeader>
            <CardTitle className={`text-lg ${plan?.text || "text-blue-400"}`}>Personalized Diet & Exercise</CardTitle>
            <CardDescription className="text-slate-400 text-xs">
              {planSource === "symptom"
                ? "Based on your reported symptoms"
                : `BMI: ${bmi?.toFixed(1)} - ${plan?.label}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {warning && <div className="p-3 bg-yellow-900 text-yellow-200 rounded text-sm">{warning}</div>}
            {plan?.notes && <div className="p-3 bg-slate-700 text-slate-200 rounded text-sm">{plan.notes}</div>}

            <div className="space-y-2 text-slate-100 text-sm">
              <div>
                <p className="font-medium text-slate-200">Breakfast</p>
                <p className="text-slate-300">{plan?.breakfast}</p>
              </div>
              <div>
                <p className="font-medium text-slate-200">Lunch</p>
                <p className="text-slate-300">{plan?.lunch}</p>
              </div>
              <div>
                <p className="font-medium text-slate-200">Dinner</p>
                <p className="text-slate-300">{plan?.dinner}</p>
              </div>
              <div className="pt-2 border-t border-slate-700">
                <p className="font-medium text-slate-200">Exercise</p>
                <p className="text-slate-300">{plan?.exercise}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "custom-diet" && (
        <Card className="border-slate-700 bg-slate-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg text-blue-400">My Diet Plans</CardTitle>
                <CardDescription className="text-slate-400 text-xs">Track disease-specific diet plans</CardDescription>
              </div>
              <Button
                size="sm"
                onClick={() => setShowDietForm(!showDietForm)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Diet Plan
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showDietForm && (
              <div className="p-4 bg-slate-700 rounded-lg space-y-3">
                <Input
                  placeholder="Disease/Condition (e.g., Diabetes, Arthritis)"
                  value={newDietPlan.disease}
                  onChange={(e) => setNewDietPlan({ ...newDietPlan, disease: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <Input
                  placeholder="Breakfast"
                  value={newDietPlan.breakfast}
                  onChange={(e) => setNewDietPlan({ ...newDietPlan, breakfast: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <Input
                  placeholder="Lunch"
                  value={newDietPlan.lunch}
                  onChange={(e) => setNewDietPlan({ ...newDietPlan, lunch: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <Input
                  placeholder="Dinner"
                  value={newDietPlan.dinner}
                  onChange={(e) => setNewDietPlan({ ...newDietPlan, dinner: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <Input
                  placeholder="Notes (optional)"
                  value={newDietPlan.notes}
                  onChange={(e) => setNewDietPlan({ ...newDietPlan, notes: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <div className="flex gap-2">
                  <Button onClick={addDietPlan} className="flex-1 bg-green-600 hover:bg-green-700">
                    Save Plan
                  </Button>
                  <Button onClick={() => setShowDietForm(false)} variant="outline" className="flex-1 border-slate-600">
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {dietPlans.length === 0 ? (
                <p className="text-slate-500 text-sm text-center py-4">
                  No diet plans added yet. Create one to get started!
                </p>
              ) : (
                dietPlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`p-4 rounded-lg border ${plan.completed ? "bg-green-950 border-green-700" : "bg-slate-700 border-slate-600"}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-start gap-3 flex-1">
                        <button onClick={() => toggleDietCompletion(plan.id)} className="mt-1">
                          {plan.completed ? (
                            <CheckCircle2 className="h-5 w-5 text-green-400" />
                          ) : (
                            <Circle className="h-5 w-5 text-slate-400" />
                          )}
                        </button>
                        <div>
                          <p
                            className={`font-semibold text-lg ${plan.completed ? "line-through text-slate-400" : "text-slate-100"}`}
                          >
                            {plan.disease}
                          </p>
                          <p className="text-xs text-slate-400 mt-1">Added: {plan.createdDate}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteDietPlan(plan.id)}
                        className="text-red-400 hover:bg-slate-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-2 text-sm text-slate-300 ml-8">
                      <div>
                        <span className="font-medium">Breakfast:</span> {plan.breakfast}
                      </div>
                      <div>
                        <span className="font-medium">Lunch:</span> {plan.lunch}
                      </div>
                      <div>
                        <span className="font-medium">Dinner:</span> {plan.dinner}
                      </div>
                      {plan.notes && (
                        <div className="text-slate-400 text-xs bg-slate-600 p-2 rounded">{plan.notes}</div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === "custom-exercise" && (
        <Card className="border-slate-700 bg-slate-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg text-blue-400">My Exercise Plans</CardTitle>
                <CardDescription className="text-slate-400 text-xs">
                  Track disease-specific exercise routines
                </CardDescription>
              </div>
              <Button
                size="sm"
                onClick={() => setShowExerciseForm(!showExerciseForm)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Exercise Plan
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showExerciseForm && (
              <div className="p-4 bg-slate-700 rounded-lg space-y-3">
                <Input
                  placeholder="Disease/Condition (e.g., Arthritis, Hypertension)"
                  value={newExercisePlan.disease}
                  onChange={(e) => setNewExercisePlan({ ...newExercisePlan, disease: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <Input
                  placeholder="Exercise Name (e.g., Walking, Swimming)"
                  value={newExercisePlan.exerciseName}
                  onChange={(e) => setNewExercisePlan({ ...newExercisePlan, exerciseName: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Duration (e.g., 30 mins)"
                    value={newExercisePlan.duration}
                    onChange={(e) => setNewExercisePlan({ ...newExercisePlan, duration: e.target.value })}
                    className="border-slate-600 bg-slate-600 text-slate-50"
                  />
                  <Input
                    placeholder="Frequency (e.g., 3x/week)"
                    value={newExercisePlan.frequency}
                    onChange={(e) => setNewExercisePlan({ ...newExercisePlan, frequency: e.target.value })}
                    className="border-slate-600 bg-slate-600 text-slate-50"
                  />
                </div>
                <select
                  value={newExercisePlan.intensity}
                  onChange={(e) => setNewExercisePlan({ ...newExercisePlan, intensity: e.target.value })}
                  className="w-full rounded border border-slate-600 bg-slate-600 px-2 py-1 text-slate-50"
                >
                  <option value="light">Light</option>
                  <option value="moderate">Moderate</option>
                  <option value="high">High</option>
                </select>
                <Input
                  placeholder="Description (optional)"
                  value={newExercisePlan.description}
                  onChange={(e) => setNewExercisePlan({ ...newExercisePlan, description: e.target.value })}
                  className="border-slate-600 bg-slate-600 text-slate-50"
                />
                <div className="flex gap-2">
                  <Button onClick={addExercisePlan} className="flex-1 bg-green-600 hover:bg-green-700">
                    Save Plan
                  </Button>
                  <Button
                    onClick={() => setShowExerciseForm(false)}
                    variant="outline"
                    className="flex-1 border-slate-600"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {exercisePlans.length === 0 ? (
                <p className="text-slate-500 text-sm text-center py-4">
                  No exercise plans added yet. Create one to get started!
                </p>
              ) : (
                exercisePlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`p-4 rounded-lg border ${plan.completed ? "bg-blue-950 border-blue-700" : "bg-slate-700 border-slate-600"}`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-start gap-3 flex-1">
                        <button onClick={() => toggleExerciseCompletion(plan.id)} className="mt-1">
                          {plan.completed ? (
                            <CheckCircle2 className="h-5 w-5 text-blue-400" />
                          ) : (
                            <Circle className="h-5 w-5 text-slate-400" />
                          )}
                        </button>
                        <div>
                          <p
                            className={`font-semibold text-lg ${plan.completed ? "line-through text-slate-400" : "text-slate-100"}`}
                          >
                            {plan.exerciseName}
                          </p>
                          <p className="text-sm text-slate-300">{plan.disease}</p>
                          <p className="text-xs text-slate-400 mt-1">Added: {plan.createdDate}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteExercisePlan(plan.id)}
                        className="text-red-400 hover:bg-slate-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-2 text-sm text-slate-300 ml-8">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <span className="font-medium">Duration:</span> {plan.duration}
                        </div>
                        <div>
                          <span className="font-medium">Frequency:</span> {plan.frequency}
                        </div>
                        <div>
                          <span className="font-medium">Intensity:</span>{" "}
                          <span className="capitalize bg-slate-600 px-2 py-1 rounded text-xs">{plan.intensity}</span>
                        </div>
                      </div>
                      {plan.description && (
                        <div className="text-slate-400 text-xs bg-slate-600 p-2 rounded">{plan.description}</div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
