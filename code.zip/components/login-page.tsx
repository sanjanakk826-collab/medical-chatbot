"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle } from "lucide-react"

interface LoginPageProps {
  onSignupClick: () => void
  onLoginSuccess: () => void
}

const initializeDemoData = () => {
  const demoUser = { id: 1, username: "demo", password: "demo123" }
  const demoRegistration = {
    name: "John Doe",
    age: 30,
    bloodGroup: "O+",
    sex: "Male",
    weight: 75,
    height: 1.75,
    systolic: 120,
    diastolic: 80,
  }
  const demoReminders = [
    {
      id: "1",
      type: "tablet",
      time: "08:00",
      message: "Take morning vitamins",
      status: "pending",
    },
    {
      id: "2",
      type: "exercise",
      time: "17:00",
      message: "30 minutes jogging",
      status: "pending",
    },
  ]
  const demoChatHistory = [
    {
      id: "1",
      type: "user",
      text: "I have a fever and headache",
    },
    {
      id: "2",
      type: "bot",
      text: "Possible Conditions: Flu, COVID-19, Meningitis\n\nRecommended Medicine: Paracetamol 500mg + rest\n\nSpecialist to Consult: General Physician\n\nWarning: Don't smoke or drink alcohol after taking tablets.",
    },
  ]

  localStorage.setItem("users", JSON.stringify([demoUser]))
  localStorage.setItem("user", JSON.stringify(demoUser))
  localStorage.setItem("registrationData", JSON.stringify(demoRegistration))
  localStorage.setItem("reminders", JSON.stringify(demoReminders))
  localStorage.setItem("chatHistory", JSON.stringify(demoChatHistory))
}

export default function LoginPage({ onSignupClick, onLoginSuccess }: LoginPageProps) {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleLogin = () => {
    if (!username || !password) {
      setError("Please fill in all fields")
      return
    }

    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u: any) => u.username === username && u.password === password)

    if (!user) {
      setError("Invalid username or password")
      return
    }

    localStorage.setItem("user", JSON.stringify(user))
    onLoginSuccess()
  }

  const handleDemoLogin = () => {
    initializeDemoData()
    onLoginSuccess()
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md border-slate-700 bg-slate-800">
        <CardHeader className="space-y-2">
          <CardTitle className="text-2xl text-blue-400">Health Assistant</CardTitle>
          <CardDescription className="text-slate-400">Sign in to your account</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex gap-2 rounded-lg bg-red-950 p-3 text-red-200">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-200">Username</label>
            <Input
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="border-slate-600 bg-slate-700 text-slate-50 placeholder:text-slate-500"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-200">Password</label>
            <Input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="border-slate-600 bg-slate-700 text-slate-50 placeholder:text-slate-500"
            />
          </div>

          <Button onClick={handleLogin} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
            Sign In
          </Button>

          <Button
            onClick={handleDemoLogin}
            variant="outline"
            className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
          >
            Try Demo
          </Button>

          <div className="text-center text-sm text-slate-400">
            {"Don't have an account? "}
            <button onClick={onSignupClick} className="text-blue-400 hover:text-blue-300 font-medium">
              Sign up
            </button>
          </div>

          <button className="w-full text-sm text-slate-400 hover:text-slate-300">Forgot Password?</button>
        </CardContent>
      </Card>
    </div>
  )
}
