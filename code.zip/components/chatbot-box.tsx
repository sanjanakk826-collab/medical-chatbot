"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Send, AlertTriangle } from "lucide-react"

interface Message {
  id: string
  type: "user" | "bot"
  text: string
  isEmergency?: boolean
}

const SYMPTOM_ANALYSIS = {
  fever: {
    diseases: ["Common Cold", "Flu", "COVID-19"],
    medicine: "Paracetamol 500mg after food",
    specialist: "General Physician",
  },
  headache: {
    diseases: ["Migraine", "Tension Headache", "Sinusitis"],
    medicine: "Ibuprofen 400mg",
    specialist: "General Physician",
  },
  "chest pain": {
    diseases: ["Angina", "Heart Attack", "Panic Attack"],
    medicine: "Seek immediate medical attention",
    specialist: "Cardiologist",
    emergency: true,
  },
  cough: {
    diseases: ["Common Cold", "Bronchitis", "Pneumonia"],
    medicine: "Cough syrup with honey",
    specialist: "Pulmonologist",
  },
  "stomach pain": {
    diseases: ["Gastritis", "IBS", "Food Poisoning"],
    medicine: "Antacid tablet",
    specialist: "Gastroenterologist",
  },
  nausea: {
    diseases: ["Food Poisoning", "Gastritis", "Migraine"],
    medicine: "Ondansetron 4mg",
    specialist: "Gastroenterologist",
  },
  "headache fever": {
    diseases: ["Flu", "COVID-19", "Meningitis"],
    medicine: "Paracetamol 500mg + rest",
    specialist: "General Physician",
  },
  "severe bleeding": {
    diseases: ["Trauma", "Internal Bleeding"],
    medicine: "Call 911 immediately",
    specialist: "Emergency",
    emergency: true,
  },
  stroke: { diseases: ["Stroke"], medicine: "Call 911 immediately", specialist: "Neurologist", emergency: true },
}

export default function ChatbotBox() {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [chatHistory, setChatHistory] = useState<Message[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const saved = localStorage.getItem("chatHistory")
    if (saved) {
      setChatHistory(JSON.parse(saved))
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const analyzeSymptoms = (text: string) => {
    const lowerText = text.toLowerCase()

    for (const [symptom, data] of Object.entries(SYMPTOM_ANALYSIS)) {
      if (lowerText.includes(symptom)) {
        localStorage.setItem("detectedSymptom", symptom)
        localStorage.setItem("detectedDisease", data.diseases[0])
        return data
      }
    }

    return null
  }

  const handleSendMessage = () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      text: input,
    }

    setMessages((prev) => [...prev, userMessage])
    const newHistory = [...chatHistory, userMessage]

    const analysis = analyzeSymptoms(input)

    if (analysis) {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        text: `
Possible Conditions: ${analysis.diseases.join(", ")}

Recommended Medicine: ${analysis.medicine}

Specialist to Consult: ${analysis.specialist}

Warning: Don't smoke or drink alcohol after taking tablets.
        `.trim(),
        isEmergency: analysis.emergency || false,
      }
      setMessages((prev) => [...prev, response])
      newHistory.push(response)
    } else {
      const response: Message = {
        id: (Date.now() + 1).toString(),
        type: "bot",
        text: "Please describe your symptoms in detail (e.g., fever, headache, chest pain) so I can provide better recommendations.",
      }
      setMessages((prev) => [...prev, response])
      newHistory.push(response)
    }

    localStorage.setItem("chatHistory", JSON.stringify(newHistory))
    setChatHistory(newHistory)
    setInput("")
  }

  return (
    <Card className="border-slate-700 bg-slate-800 h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-lg text-blue-400">AI Health Assistant</CardTitle>
        <CardDescription className="text-slate-400 text-xs">Describe your symptoms</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col">
        <div className="flex-1 space-y-3 mb-4 overflow-y-auto max-h-64">
          {messages.length === 0 ? (
            <p className="text-slate-500 text-sm">Start by describing your symptoms...</p>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-lg ${
                  msg.type === "user"
                    ? "bg-blue-600 text-white ml-auto w-fit max-w-xs"
                    : msg.isEmergency
                      ? "bg-red-950 text-red-200"
                      : "bg-slate-700 text-slate-100"
                }`}
              >
                {msg.isEmergency && (
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="h-4 w-4" /> EMERGENCY
                  </div>
                )}
                <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="flex gap-2">
          <Input
            placeholder="Describe symptoms..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            className="border-slate-600 bg-slate-700 text-slate-50"
          />
          <Button onClick={handleSendMessage} className="bg-blue-600 hover:bg-blue-700" size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
