"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import ChatbotBox from "./chatbot-box"
import DietExerciseBox from "./diet-exercise-box"
import RemindersBox from "./reminders-box"
import SpecialistDirectory from "./specialist-directory"
import ChatHistory from "./chat-history"
import UserProfile from "./user-profile"
import { useLanguage } from "@/context/language-context"

interface DashboardPageProps {
  onLogout: () => void
}

type Tab = "chatbot" | "chat-history" | "diet" | "reminders" | "specialists" | "profile"

export default function DashboardPage({ onLogout }: DashboardPageProps) {
  const [user, setUser] = useState<any>(null)
  const [activeTab, setActiveTab] = useState<Tab>("chatbot")
  const { t, language, setLanguage } = useLanguage()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
  }, [])

  const navItems = [
    { id: "chatbot" as Tab, label: t("nav.aiChat"), icon: "MessageSquare" },
    { id: "chat-history" as Tab, label: t("nav.chatHistory"), icon: "History" },
    { id: "diet" as Tab, label: t("nav.diet"), icon: "Apple" },
    { id: "reminders" as Tab, label: t("nav.reminders"), icon: "Bell" },
    { id: "specialists" as Tab, label: t("nav.specialists"), icon: "Stethoscope" },
    { id: "profile" as Tab, label: t("nav.profile"), icon: "User" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Header */}
      <div className="bg-slate-800 border-b border-slate-700 p-6 sticky top-0 z-10">
        <div className="mx-auto max-w-7xl flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-blue-400">{t("dashboard.title")}</h1>
            <p className="text-slate-400 mt-1">
              {t("dashboard.welcome")}, {user?.username}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {/* Language Selector */}
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="rounded border border-slate-600 bg-slate-700 px-3 py-2 text-slate-50 text-sm hover:bg-slate-600"
            >
              <option value="en">{t("language.english")}</option>
              <option value="hi">{t("language.hindi")}</option>
              <option value="kn">{t("language.kannada")}</option>
            </select>
            <Button
              onClick={onLogout}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:bg-slate-700 bg-transparent"
            >
              <LogOut className="h-4 w-4 mr-2" />
              {t("dashboard.logout")}
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-slate-800 border-b border-slate-700 px-6 py-4">
        <div className="mx-auto max-w-7xl">
          <div className="flex gap-2 overflow-x-auto">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-all ${
                  activeTab === item.id ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl p-6">
        {activeTab === "chatbot" && (
          <div className="w-full">
            <ChatbotBox />
          </div>
        )}

        {activeTab === "chat-history" && (
          <div className="w-full">
            <ChatHistory />
          </div>
        )}

        {activeTab === "diet" && (
          <div className="w-full">
            <DietExerciseBox />
          </div>
        )}

        {activeTab === "reminders" && (
          <div className="w-full">
            <RemindersBox />
          </div>
        )}

        {activeTab === "specialists" && (
          <div className="w-full">
            <SpecialistDirectory />
          </div>
        )}

        {activeTab === "profile" && (
          <div className="w-full">
            <UserProfile />
          </div>
        )}
      </div>
    </div>
  )
}
