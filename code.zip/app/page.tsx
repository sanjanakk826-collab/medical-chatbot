"use client"

import { useState } from "react"
import LoginPage from "@/components/login-page"
import SignupPage from "@/components/signup-page"
import RegistrationPage from "@/components/registration-page"
import DashboardPage from "@/components/dashboard-page"

type PageState = "login" | "signup" | "registration" | "dashboard"

export default function Home() {
  const [currentPage, setCurrentPage] = useState<PageState>(() => {
    if (typeof window !== "undefined") {
      const user = localStorage.getItem("user")
      return user ? "dashboard" : "login"
    }
    return "login"
  })

  const handleSignup = () => setCurrentPage("signup")
  const handleLogin = () => setCurrentPage("login")
  const handleRegister = () => setCurrentPage("registration")
  const handleRegistrationComplete = () => setCurrentPage("dashboard")
  const handleLogout = () => {
    localStorage.removeItem("user")
    localStorage.removeItem("registrationData")
    setCurrentPage("login")
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {currentPage === "login" && (
        <LoginPage onSignupClick={handleSignup} onLoginSuccess={handleRegistrationComplete} />
      )}
      {currentPage === "signup" && <SignupPage onLoginClick={handleLogin} onSignupSuccess={handleRegister} />}
      {currentPage === "registration" && <RegistrationPage onRegistrationComplete={handleRegistrationComplete} />}
      {currentPage === "dashboard" && <DashboardPage onLogout={handleLogout} />}
    </main>
  )
}
