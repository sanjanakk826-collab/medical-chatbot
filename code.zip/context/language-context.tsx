"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Language = "en" | "hi" | "kn"

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const translations = {
  en: {
    // Dashboard
    "dashboard.title": "Health Dashboard",
    "dashboard.welcome": "Welcome",
    "dashboard.logout": "Logout",

    // Navigation
    "nav.aiChat": "AI Health Chat",
    "nav.chatHistory": "Chat History",
    "nav.diet": "Diet & Exercise",
    "nav.reminders": "Reminders",
    "nav.specialists": "Specialists",
    "nav.profile": "My Profile",

    // Reminders
    "reminders.title": "Reminders & Tracking",
    "reminders.subtitle": "Manage your health reminders",
    "reminders.add": "Add",
    "reminders.type": "Reminder Type",
    "reminders.tablet": "Tablet/Medicine",
    "reminders.diet": "Diet",
    "reminders.exercise": "Exercise",
    "reminders.time": "Time",
    "reminders.message": "Custom message",
    "reminders.save": "Save Reminder",
    "reminders.empty": "No reminders set. Add one to get started!",
    "reminders.marked": "Mark Taken",
    "reminders.delete": "Delete",
    "reminders.pending": "PENDING",
    "reminders.taken": "TAKEN",
    "reminders.missed": "MISSED",
    "reminders.notification": "Reminder Alert",
    "reminders.enableNotifications": "Enable Notifications",
    "reminders.disableNotifications": "Disable Notifications",
    "reminders.notificationsEnabled": "Browser notifications are enabled",
    "reminders.notificationsDisabled": "Browser notifications are disabled",
    "reminders.alarmEnabled": "Enable Alert",
    "reminders.alarmDisabled": "Disable Alert",

    // Specialists
    "specialists.title": "Specialists Directory",
    "specialists.book": "Book Consultation",
    "specialists.contact": "Contact",
    "specialists.available": "Available",
    "specialists.date": "Select Date",
    "specialists.time": "Select Time",
    "specialists.confirm": "Confirm Booking",

    // Diet & Exercise
    "diet.title": "Diet & Exercise Plan",
    "diet.recommended": "Recommended Plan",
    "diet.myDiet": "My Diet Plans",
    "diet.myExercise": "My Exercise Plans",
    "diet.add": "Add Diet Plan",
    "diet.exercise": "Add Exercise Plan",
    "diet.completed": "Completed",

    // Chat
    "chat.title": "AI Health Assistant",
    "chat.send": "Send",
    "chat.type": "Type your health question...",

    // Language
    "language.select": "Select Language",
    "language.english": "English",
    "language.hindi": "Hindi",
    "language.kannada": "Kannada",
  },
  hi: {
    // Dashboard
    "dashboard.title": "स्वास्थ्य डैशबोर्ड",
    "dashboard.welcome": "स्वागत है",
    "dashboard.logout": "लॉग आउट",

    // Navigation
    "nav.aiChat": "एआई स्वास्थ्य चैट",
    "nav.chatHistory": "चैट इतिहास",
    "nav.diet": "आहार और व्यायाम",
    "nav.reminders": "अनुस्मारक",
    "nav.specialists": "विशेषज्ञ",
    "nav.profile": "मेरी प्रोफाइल",

    // Reminders
    "reminders.title": "अनुस्मारक और ट्रैकिंग",
    "reminders.subtitle": "अपने स्वास्थ्य अनुस्मारक प्रबंधित करें",
    "reminders.add": "जोड़ें",
    "reminders.type": "अनुस्मारक प्रकार",
    "reminders.tablet": "दवा/गोली",
    "reminders.diet": "आहार",
    "reminders.exercise": "व्यायाम",
    "reminders.time": "समय",
    "reminders.message": "कस्टम संदेश",
    "reminders.save": "अनुस्मारक सहेजें",
    "reminders.empty": "कोई अनुस्मारक सेट नहीं है। शुरू करने के लिए एक जोड़ें!",
    "reminders.marked": "ली गई के रूप में चिह्नित करें",
    "reminders.delete": "हटाएं",
    "reminders.pending": "लंबित",
    "reminders.taken": "ली गई",
    "reminders.missed": "छूटी हुई",
    "reminders.notification": "अनुस्मारक सतर्कता",
    "reminders.enableNotifications": "सूचनाएं सक्षम करें",
    "reminders.disableNotifications": "सूचनाएं अक्षम करें",
    "reminders.notificationsEnabled": "ब्राउज़र सूचनाएं सक्षम हैं",
    "reminders.notificationsDisabled": "ब्राउज़र सूचनाएं अक्षम हैं",
    "reminders.alarmEnabled": "अलर्ट सक्षम करें",
    "reminders.alarmDisabled": "अलर्ट अक्षम करें",

    // Specialists
    "specialists.title": "विशेषज्ञ निर्देशिका",
    "specialists.book": "परामर्श बुक करें",
    "specialists.contact": "संपर्क",
    "specialists.available": "उपलब्ध",
    "specialists.date": "तारीख चुनें",
    "specialists.time": "समय चुनें",
    "specialists.confirm": "बुकिंग की पुष्टि करें",

    // Diet & Exercise
    "diet.title": "आहार और व्यायाम योजना",
    "diet.recommended": "अनुशंसित योजना",
    "diet.myDiet": "मेरी आहार योजनाएं",
    "diet.myExercise": "मेरी व्यायाम योजनाएं",
    "diet.add": "आहार योजना जोड़ें",
    "diet.exercise": "व्यायाम योजना जोड़ें",
    "diet.completed": "पूर्ण",

    // Chat
    "chat.title": "एआई स्वास्थ्य सहायक",
    "chat.send": "भेजें",
    "chat.type": "अपना स्वास्थ्य प्रश्न टाइप करें...",

    // Language
    "language.select": "भाषा चुनें",
    "language.english": "अंग्रेजी",
    "language.hindi": "हिंदी",
    "language.kannada": "कन्नड़",
  },
  kn: {
    // Dashboard
    "dashboard.title": "ಆರೋಗ್ಯ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    "dashboard.welcome": "ಸ್ವಾಗತವಾಗಿದೆ",
    "dashboard.logout": "ಲಾಗ್ ಔಟ್",

    // Navigation
    "nav.aiChat": "AI ಆರೋಗ್ಯ ಚ್ಯಾಟ್",
    "nav.chatHistory": "ಚ್ಯಾಟ್ ಇತಿಹಾಸ",
    "nav.diet": "ಆಹಾರ ಮತ್ತು ವ್ಯಾಯಾಮ",
    "nav.reminders": "ಜ್ಞಾಪನೆಗಳು",
    "nav.specialists": "ತಜ್ಞರು",
    "nav.profile": "ನನ್ನ ಪ್ರೋಫೈಲ್",

    // Reminders
    "reminders.title": "ಜ್ಞಾಪನೆಗಳು ಮತ್ತು ಟ್ರ್ಯಾಕಿಂಗ್",
    "reminders.subtitle": "ನಿಮ್ಮ ಆರೋಗ್ಯ ಜ್ಞಾಪನೆಗಳನ್ನು ನಿರ್ವಹಿಸಿ",
    "reminders.add": "ಸೇರಿಸಿ",
    "reminders.type": "ಜ್ಞಾಪನೆಯ ಪ್ರಕಾರ",
    "reminders.tablet": "ಔಷಧ/ಟ್ಯಾಬ್ಲೆಟ್",
    "reminders.diet": "ಆಹಾರ",
    "reminders.exercise": "ವ್ಯಾಯಾಮ",
    "reminders.time": "ಸಮಯ",
    "reminders.message": "ಕಸ್ಟಮ ಸಂದೇಶ",
    "reminders.save": "ಜ್ಞಾಪನೆ ಸಂರಕ್ಷಿಸಿ",
    "reminders.empty": "ಯಾವುದೇ ಜ್ಞಾಪನೆಗಳನ್ನು ಹೊಂದಿಸಲಾಗಿಲ್ಲ. ಪ್ರಾರಂಭಿಸಲು ಒಂದನ್ನು ಸೇರಿಸಿ!",
    "reminders.marked": "ತೆಗೆದುಕೊಂಡ ಎಂದು ಗುರುತಿಸಿ",
    "reminders.delete": "ಅಳಿಸಿ",
    "reminders.pending": "ಪರಿ್ಬಂಧಿತ",
    "reminders.taken": "ತೆಗೆದುಕೊಂಡ",
    "reminders.missed": "ತಪ್ಪಿಸಿದ",
    "reminders.notification": "ಜ್ಞಾಪನೆ ಎಚ್ಚರಿಕೆ",
    "reminders.enableNotifications": "ಸೂಚನೆಗಳನ್ನು ಸಕ್ರಿಯಗೊಳಿಸಿ",
    "reminders.disableNotifications": "ಸೂಚನೆಗಳನ್ನು ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ",
    "reminders.notificationsEnabled": "ಬ್ರೌಜರ್ ಸೂಚನೆಗಳು ಸಕ್ರಿಯವಾಗಿವೆ",
    "reminders.notificationsDisabled": "ಬ್ರೌಜರ್ ಸೂಚನೆಗಳು ನಿಷ್ಕ್ರಿಯವಾಗಿವೆ",
    "reminders.alarmEnabled": "ಅಲರ್ಟ್ ಸಕ್ರಿಯಗೊಳಿಸಿ",
    "reminders.alarmDisabled": "ಅಲರ್ಟ್ ನಿಷ್ಕ್ರಿಯಗೊಳಿಸಿ",

    // Specialists
    "specialists.title": "ತಜ್ಞ ನಿರ್ದೇಶಿಕೆ",
    "specialists.book": "ಸಂಪರ್ಕ ಬುಕ್ ಮಾಡಿ",
    "specialists.contact": "ಸಂಪರ್ಕ",
    "specialists.available": "ಲಭ್ಯ",
    "specialists.date": "ದಿನಾಂಕ ಆರಿಸಿ",
    "specialists.time": "ಸಮಯ ಆರಿಸಿ",
    "specialists.confirm": "ಬುಕಿಂಗ್ ದೃಢೀಕರಿಸಿ",

    // Diet & Exercise
    "diet.title": "ಆಹಾರ ಮತ್ತು ವ್ಯಾಯಾಮ ಯೋಜನೆ",
    "diet.recommended": "ಸೂಚಿಸಲಾದ ಯೋಜನೆ",
    "diet.myDiet": "ನನ್ನ ಆಹಾರ ಯೋಜನೆಗಳು",
    "diet.myExercise": "ನನ್ನ ವ್ಯಾಯಾಮ ಯೋಜನೆಗಳು",
    "diet.add": "ಆಹಾರ ಯೋಜನೆ ಸೇರಿಸಿ",
    "diet.exercise": "ವ್ಯಾಯಾಮ ಯೋಜನೆ ಸೇರಿಸಿ",
    "diet.completed": "ಪೂರ್ಣಗೊಂಡಿದೆ",

    // Chat
    "chat.title": "AI ಆರೋಗ್ಯ ಸಹಾಯಕ",
    "chat.send": "ಕಳುಹಿಸಿ",
    "chat.type": "ನಿಮ್ಮ ಆರೋಗ್ಯ ಪ್ರಶ್ನೆ ಟೈಪ್ ಮಾಡಿ...",

    // Language
    "language.select": "ಭಾಷೆ ಆರಿಸಿ",
    "language.english": "ಇಂಗ್ಲಿಷ್",
    "language.hindi": "ಹಿಂದಿ",
    "language.kannada": "ಕನ್ನಡ",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>("en")

  useEffect(() => {
    const saved = localStorage.getItem("language") as Language
    if (saved && ["en", "hi", "kn"].includes(saved)) {
      setLanguageState(saved)
    }
  }, [])

  const setLanguage = (lang: Language) => {
    setLanguageState(lang)
    localStorage.setItem("language", lang)
  }

  const t = (key: string): string => {
    return (translations[language] as any)[key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within LanguageProvider")
  }
  return context
}
